from scipy.optimize import curve_fit
import numpy as np

# Given data
miles = np.array([16.7, 16.0, 15.9, 15.4])
fare = np.array([69.73, 69.14, 67.08, 65.4])

# Define the fare calculation function


def fare_function(miles, x, y):
    return 56.79 + (miles - x) * y


# Fit the curve to find the optimal values of x and y
popt, _ = curve_fit(fare_function, miles, fare)

# Extracting the values of x and y
x, y = popt

print("Optimal value of x:", x)
print("Optimal value of y:", y)
calculated_fares = fare_function(miles, x, y)

# Print the calculated fares for the given miles
print("\nCalculated fares for the given miles:")
for i in range(len(miles)):
    print(f"For {miles[i]} miles, the fare is {calculated_fares[i]}")
